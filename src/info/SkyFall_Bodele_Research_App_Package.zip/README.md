# SkyFall / Bodélé app data package

## Files
- `skyfall_bodele_app_data.json`: main app payload (site recommendation, evidence, Mars reference summaries, acquisition plan, sources).
- `site_candidates.csv`: Chicha candidate point and published wind-lens context regions.
- `evidence_metrics.csv`: reported Bodélé measurements and provisional Mars summary statistics.
- `data_acquisition_status.csv`: what is catalogued versus what still requires download/processing.

## React / Next.js use
Load the JSON as a static data asset or serve it from an API route. CSVs can power downloadable tables and charts. Do not interpret missing values as zero.

## Important data integrity notes
1. Chicha (16.88 N, 18.53 E, 179 m) is a published BoDEx field-site coordinate, not a surveyed helicopter pad polygon.
2. The 2025 wind-lens entrance/exit rectangles are large regional analysis boxes, not flight-test boundaries.
3. ERA5/MERRA-2/MODIS raw gridded data are not downloaded in this package. Published ERA5/MODIS findings are cited as literature results; the acquisition CSV specifies the next requests.
4. MEDA hourly workbook statistics are computed from the supplied compiled workbook. Wind appears in only 4,095 of 18,728 rows; this is incomplete coverage and not gust data.
5. MCS summary refers to one four-hour product (2025-07-01, Ls ~104.28). Dust is spectral opacity per km at 21.6 um, not dust mass concentration or particle count. Quality flags must be preserved.
6. No Earth location reproduces Mars' low atmospheric density and gravity. Use Bodélé for environmental/instrument stress tests, not Mars rotorcraft flight-envelope validation.
7. A single numeric analogue score is deliberately withheld until raw multi-year Earth datasets and alternative candidate sites are processed.

## Recommended next data pipeline
ERA5 hourly wind/temperature/pressure/radiation -> MERRA-2 dust mass/AOT -> MODIS MAIAC daily AOD/dust screening -> DEM/imagery pad screening -> distributional Mars comparison (percentiles, KS and Wasserstein distances).
